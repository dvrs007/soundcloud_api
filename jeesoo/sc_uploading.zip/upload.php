<?php
session_start();
require_once 'Services/Soundcloud.php';
require_once 'sc_credentials.php';

//include 'your header file';

// create a client object with your app credentials
$sc_connection = new Services_Soundcloud(
	CLIENT_ID, 
	CLIENT_SECRET, 
	CALL_BACK_URI);
	
$sc_connection->setDevelopment(false);
//********************************************************************//
//if there exists the post method,
//the client object will set the access token which has been posted 
//and
//the array will store the track information which has been posted by a form below.

if($_POST){ 
  
  $sc_connection->setAccessToken($_POST['access_token']);
 
  // The posted information will be set for the value of '/track'.
  $mytrack = array(
    'track[title]' => $_POST["audioname"],
    'track[asset_data]' => '@'.$_FILES["audiofile"]["tmp_name"] 
     );
 
  // the posted information from the $mytrack array will be posted to '/tracks' under user's account 
  $track = json_decode($sc_connection->post('tracks', $mytrack));
  
  
  //Successful upload will generate the following message with a link to the page with uploaded sound file.
  echo '<p>File has been successfully uploaded to your Soundcloud account. <br/>'
  . 'Please click <b><a href="'.$track->permalink_url.'" target="_blank" >HERE</a></b> to listen to.</p>';
}
else 
if($_GET['access_token']){
?>



<body>

<form action="" method="post" enctype="multipart/form-data">
  <input type="hidden" name="access_token" value="<?php echo $_GET['access_token']; ?>" />
  <br />
  Audio Name:
  <input type="text" name="audioname" placeholder="My audio" />
  <br />
  <br />
  Audio File:
  <input type="file" name="audiofile" id="audiofile" />
  <br />
  <br />
  <input type="submit" />
</form>



<?php
}
else{
   header("Location:YOUR_REDIRECT_URI_SHOULD_BE_HERE");
}


//include 'your footer file';
?>   