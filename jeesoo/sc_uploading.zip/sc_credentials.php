<?php


define( 'CLIENT_ID' , 'change this with YOUR CLIENT ID');
define( 'CLIENT_SECRET' , 'change this with YOUR CLIENT SECRET');
define( 'CALL_BACK_URI', 'change this with YOUR Redirect URI');


?>