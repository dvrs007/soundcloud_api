<?php 

require_once '../php-soundcloud-master/Services/Soundcloud.php';

// create client object with app credentials
$client = new Services_Soundcloud(
	'YOUR_CLIENT_ID', 
	'YOUR_CLIENT_SECRET', 
	'YOUR_REDIRECT_URL'
);

// exchange authorization code for access token
$code = $_GET['code'];
$access_token = $client->accessToken($code);

// make an authenticated call
$current_user = json_decode($client->get('me'));
$scUser = $current_user->username;

$tracks = $client->get('tracks', array('q' => 'Stephan Bodzin'));


$decodedtracks = json_decode($tracks);


$client->setCurlOptions(array(CURLOPT_FOLLOWLOCATION => 1));

foreach($decodedtracks as $s){
    $track_url = $s->permalink_url;
    echo "Track url: " . $track_url . "<br />";

    $embed_info = json_decode($client->get('oembed', array('url' => $track_url)));

	//render the html for the player widget
	print $embed_info->html;

 
}