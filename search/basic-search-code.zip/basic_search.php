<!doctype html>
<html>
	<head>

		<meta charset="UTF-8"/>
		<title>Basic SoundCloud Search using PHP</title>

	</head>
	<body>

		<form method="post" action=".">

			<label for="search">Enter your search keyword:</label>
			<input type="text" name="search" />
			<input type="submit" name="submit" />

		</form>

		<p><strong>Results for... <?php echo $query; ?></strong></p>

		<?php 

			//loop through and display results
			foreach ($results_array as $r) {
				
				echo '<div class="search-result">';
				echo '<p>User: ' . $r->user->username . '</p>';
				echo '<p>Track Title: ' . $r->title . '</p>';
				echo '<p>Genre: ' . $r->genre . '</p></div>';

			}

		?>

	</body>
</html>