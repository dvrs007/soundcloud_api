<!DOCTYPE html>
<html>
    <head>





    
<script src="//connect.soundcloud.com/sdk.js">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    
        <script>
            //initialize your cilent with your own client_id
            //you could also put in your redirect url
            //but in this example we will not be using the redirect url 
  SC.initialize({
    client_id: "YOUR_CLIENT_ID"
  });
  
  //when the document is loaded this function will be
  //ready/available to be used
  
    $(document).ready(function() {
// to use the SDK , the streaming function is powered by
//soundmanager2 library, this will auto load by the SDK


// this part is where you use the SoundCloud stream for a track
// for this example we will be using a given track by soundcloud
// so we will call the soundcloud SDK stream
// what it does is converts the track to an object
// we will call the SC.stream and then pass a path to a track
// and then a callback function, the callback function
//will take one argument called sound
SC.stream('/tracks/293', function(sound) {
// this is where we will make two buttonz which will have the id play and stop
//we will create a function that when the buttons are clicked it will play or stop the sound

//when the button with the id is clicked the function will have an event

$('#play').click(function(e) {
//when the the function is click the event will prevent default which this method will not accept any arguments
    e.preventDefault();
//the argument sound will then play
    sound.play();
  });

  $('#stop').click(function(e) {
    e.preventDefault();
//the arguemnt sound will then stop
    sound.stop();
  }); 
});
});
    
   
    
</script>
        

<button id="play"> Play</button>
<button id="stop">Stop</button>


